package com.cognizant.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.controller.HangarController;
import com.cognizant.controller.PilotController;
import com.cognizant.model.PilotModel;
import com.cognizant.service.PilotService;
import com.cognizant.service.PilotServiceImpl;

public class TestPilotController {
	
	private MockMvc mockMvc;
	
	@Spy
	@Autowired
	private PilotServiceImpl pilotService;
	
	@Spy
	@Autowired
	@Qualifier("pilotValidator")
	private Validator validator;
	
	 @InjectMocks
	 private PilotController pilotController;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders
                .standaloneSetup(pilotController)
                .build();
	}

	

	@Test
	public void testPersistPilotMethod_positive() {
		
		PilotModel pilotModel = new PilotModel();
	   	pilotModel.setPilotId(1);
    	pilotModel.setPilotLicenseNumber("11");
    	pilotModel.setPilotAddressLine1("address1");
    	pilotModel.setPilotAddressLine2("address2");
    	pilotModel.setPilotCity("Lucknow");
    	pilotModel.setPilotState("UP");
    	pilotModel.setPilotZipCode(111);
    	pilotModel.setPilotSsn(10);
 	
		Errors errors = new BeanPropertyBindingResult(pilotModel, "pilotId");
		
		ModelAndView mv = pilotController.persistPilot(pilotModel, errors);
		
		String actual = mv.getViewName();
		String expected ="pilotForm";
		assertEquals(expected,actual);
		
	}
	
	@Test
public void testUpdatePilotMethod_positive() {
		
		PilotModel pilotModel = new PilotModel();
	   	pilotModel.setPilotId(1);
    	pilotModel.setPilotLicenseNumber("11");
    	pilotModel.setPilotAddressLine1("address1");
    	pilotModel.setPilotAddressLine2("address2");
    	pilotModel.setPilotCity("Lucknow");
    	pilotModel.setPilotState("UP");
    	pilotModel.setPilotZipCode(111);
    	pilotModel.setPilotSsn(10);
		
		Errors errors = new BeanPropertyBindingResult(pilotModel, "pilotId");
		
		ModelAndView mv = pilotController.updatePilot(pilotModel, errors);
		
		String actual = mv.getViewName();
		String expected ="viewOnePilot";
		assertEquals(expected,actual);
		
	}
	
	@Test
	public void testViewPilotMethod_positive() {
			ModelMap map = new ModelMap();
			PilotModel pilotModel = new PilotModel();
		   	pilotModel.setPilotId(1);
	    	pilotModel.setPilotLicenseNumber("11");
	    	pilotModel.setPilotAddressLine1("address1");
	    	pilotModel.setPilotAddressLine2("address2");
	    	pilotModel.setPilotCity("Lucknow");
	    	pilotModel.setPilotState("UP");
	    	pilotModel.setPilotZipCode(111);
	    	pilotModel.setPilotSsn(10);
			
			Errors errors = new BeanPropertyBindingResult(pilotModel, "pilotId");
			
			ModelAndView mv = pilotController.viewPilot(map, pilotModel, 55);
			String actual = mv.getViewName();
			String expected ="pilotForm";
			assertEquals(expected,actual);
			
		}
}
