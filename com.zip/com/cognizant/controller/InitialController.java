package com.cognizant.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 
 * @author 768812
 * 
 * Initial Controller will manage front page operations
 */

@Controller
public class InitialController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	/*
	 * Loading of only main page where
	 * user will select to login as Admin or as Manager
	 */
	
	@RequestMapping(value ="index.htm")
	public String main(){
		logger.info("----Loading Main Page in Initial Controller----");
		return "main";
	}
	
	/*
	 * when session is expired restrict the allocation request
	 */
	
	@RequestMapping(value ="main.htm")
	public String main1(){
		logger.info("----Loading Main Page in Initial Controller----");
		return "main";
	}

	/*
	 * if any problem occurs during login or other details are there on contact page
	 * for help
	 */
	
	@RequestMapping(value ="contact.htm")
	public String contact(){
		logger.info("----Loading Contact Page in Initial Controller----");
		return "contact";
	}

	/*
	 * Describe our project value
	 */
	
	@RequestMapping(value ="about.htm")
	public String about(){
		logger.info("----Loading About Page in Initial Controller----");
		return "about";
	}

}
