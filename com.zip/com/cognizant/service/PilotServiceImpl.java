package com.cognizant.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cognizant.dao.PilotDAO;
import com.cognizant.entity.Pilot;
import com.cognizant.model.PilotModel;
/**
 * 
 * @author 768812
 *All the Business Logic of pilot will be here.
 */
@Service("PilotServiceImpl")
public class PilotServiceImpl implements PilotService {
	// used to forming computation

	@Autowired
	@Qualifier("PilotDAOImpl")
	private PilotDAO pilotDAO;

	private static final Logger logger = LoggerFactory.getLogger(PilotServiceImpl.class);

	/*
	 * Get all pilots details.
	 */
	
	@Override
	public List<Pilot> getAllPilots() {
		logger.info("----Retriving List of all Pilot in Pilot Service----");
		return pilotDAO.getAllPilots();
	}

	/*
	 * persist pilots details.
	 */
	
	@Override
	public boolean persistPilot(PilotModel pilotModel) {
		logger.info("----Register Pilot in Pilot Service----");
		Pilot pilot=new Pilot();
		
		//pilot.setPilotId(pilotModel.getPilotId());
		
		pilot=pilotModel.modelToEntity(pilotModel);		
		return pilotDAO.insertPilot(pilot);
	}

	/*
	 * get Pilot info.
	 */
	
	@Override
	public PilotModel getPilot(int pilot1) {
	logger.info("----Retriving One Pilot using Pilot Id in Pilot Service----");

	Pilot pilot= pilotDAO.getPilot(pilot1);
	PilotModel pilotModel=new PilotModel();
		
	pilotModel=pilotModel.entityToModel(pilot);		
	return pilotModel;

	}

	/*
	 * Update pilot informations.
	 */
	
	@Override
	public boolean updatePilot(PilotModel pilotModel) {
		logger.info("----Updating Pilot in Pilot Service----");
		Pilot pilot=new Pilot();		
		pilot=pilotModel.modelToEntity(pilotModel);			
		pilot.setPilotId(pilotModel.getPilotId());
		return pilotDAO.updatePilot(pilot);
	}

}
