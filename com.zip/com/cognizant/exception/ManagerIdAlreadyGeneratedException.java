package com.cognizant.exception;

public class ManagerIdAlreadyGeneratedException extends RuntimeException {

	private String message;
	
	public ManagerIdAlreadyGeneratedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
}
